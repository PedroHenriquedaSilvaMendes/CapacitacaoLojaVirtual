import 'package:flutter/material.dart';
import 'package:lojavirtual/models/user_model.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:scoped_model/scoped_model.dart';

class SignUpScreen extends StatefulWidget {

  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
 
   final _nameController = TextEditingController();
    final _emailController = TextEditingController();
    final _passController = TextEditingController();
    final _adressController = TextEditingController();

    final _formKey = GlobalKey<FormState>();
    final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldMessengerKey,
      appBar: AppBar(
        title: Text('Criar Conta'),
        centerTitle: true,
      ),
      body: ScopedModelDescendant<UserModel>(
        builder: (context, child, model){
          if (model.isLoading)
            return Center(child: CircularProgressIndicator(),);
          return Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsetsDirectional.all(16.0),
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Nome completo',
              ),
              controller: _nameController,
              validator: (text){
                if (text!.isEmpty) return 'Nome inválido';
              },
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 16.0,),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'E-Mail',
              ),
              controller: _emailController,
              validator: (text){
                if (text!.isEmpty || !text.contains('@') || !text.contains('.com')) return 'E-Mail inválido';
              },
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 16.0,),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Senha',
              ),
              controller: _passController,
              validator: (text){
                if (text!.isEmpty || text.length < 6) return 'Senha inválida';
              },
              obscureText: true,
            ),
            SizedBox(height: 16.0,),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Endereço',
              ),
              controller: _adressController,
              validator: (text){
                if (text!.isEmpty) return 'Endereço inválido';
              },
            ),
            SizedBox(height: 16.0,),
            SizedBox(height: 16.0,),
            ElevatedButton(
              child: Text('Cadastrar'),
              style: ElevatedButton.styleFrom(
                      textStyle: TextStyle(
                      fontSize: 18.0,
                      color: Colors.white,
                    ),
                      primary: Theme.of(context).primaryColor,
                    ),
              onPressed: (){
                if(_formKey.currentState!.validate()){

                  Map<String, dynamic> userData = {
                    'name' : _nameController.text,
                    'email' : _emailController.text,
                    'adress' : _adressController.text,
                  };

                    model.signUp(
                      userData,
                      _passController.text,
                      _onSucess,
                      _onFail,
                    );
                }
              },
              ),
          ],
        ),
      );
        }
        )
    );
  }
  void _onSucess(){
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(content: Text('Usuário criado com sucesso!'),
        backgroundColor: Theme.of(context).primaryColor,
        duration: Duration(seconds: 2)
        ,)
      );
      Future.delayed(Duration(seconds: 2)).then((_){
        Navigator.of(context).pop();
      });
  }
  void _onFail(){
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(content: Text('Falha ao criar usuário!'),
        backgroundColor: Colors.redAccent,
        duration: Duration(seconds: 2)
        ,)
        );
  }

}
