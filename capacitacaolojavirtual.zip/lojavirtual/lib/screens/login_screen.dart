import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lojavirtual/models/user_model.dart';
import 'package:lojavirtual/screens/signup_screen.dart';

import 'package:scoped_model/scoped_model.dart';

class LoginScreen extends StatefulWidget {

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldMessengerKey,
      appBar: AppBar(
        title: Text('Entrar'),
        centerTitle: true,
        actions: <Widget>[
          TextButton(
          child: Text(
            'Criar Conta',
            style: TextStyle(
              fontSize: 15.0,
              color: Colors.white,
            ),
          ),
          onPressed: (){
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (context)=>SignUpScreen()
              ),
            );
          },
          ),
        ],
      ),
      body: ScopedModelDescendant<UserModel>(
        builder: (context, child, model) {
          if (model.isLoading)
            return Center(child: CircularProgressIndicator(),);

          return Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsetsDirectional.all(16.0),
          children: <Widget>[
            TextFormField(
              decoration: InputDecoration(
                hintText: 'E-Mail',
              ),
              controller: _emailController,
              validator: (text){
                if (text!.isEmpty || !text.contains('@')) return 'E-Mail inválido';
              },
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 16.0,),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'Senha',
              ),
              controller: _passController,
              validator: (text){
                if (text!.isEmpty || text.length < 6) return 'Senha inválida';
              },
              obscureText: true,
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: EdgeInsets.zero,
                child: TextButton(
                          child: Text('Esqueci minha senha',
                          textAlign: TextAlign.right,
                          ),
                          onPressed: (){
                            if (_emailController.text.isEmpty)
                             _scaffoldMessengerKey.currentState?.showSnackBar(
                            SnackBar(content: Text('Insira seu email para recuperação!'),
                            backgroundColor: Colors.redAccent,
                            duration: Duration(seconds: 2)
                            ,)
                            );
                            else {
                              model.recoverPass(_emailController.text);
                              _scaffoldMessengerKey.currentState?.showSnackBar(
                              SnackBar(content: Text('Confira seu email!'),
                              backgroundColor: Theme.of(context).primaryColor,
                              duration: Duration(seconds: 2)
                              ,)
                              );
                            }
                          }
                ),
              ),
            ),
            SizedBox(height: 16.0,),
            ElevatedButton(
              child: Text('Entrar'),
              style: ElevatedButton.styleFrom(
                      textStyle: TextStyle(
                      fontSize: 18.0,
                      color: Colors.white,
                    ),
                      primary: Theme.of(context).primaryColor,
                    ),
              onPressed: (){
                if(_formKey.currentState!.validate()){

                }
                model.signIn(
                  _emailController.text,
                  _passController.text,
                  _onSuccess,
                  _onFail
                );
              },
              ),
          ],
        ),
      );
        }
        )
    );
  }
  void _onSuccess(){
      Navigator.of(context).pop();
  }
  void _onFail(){
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(content: Text('Falha ao entrar!'),
        backgroundColor: Colors.redAccent,
        duration: Duration(seconds: 2)
        ,)
        );
  }
  }


